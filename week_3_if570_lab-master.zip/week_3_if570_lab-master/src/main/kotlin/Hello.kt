fun swim(speed: String = "fast") {
    println("swimming $speed")
}